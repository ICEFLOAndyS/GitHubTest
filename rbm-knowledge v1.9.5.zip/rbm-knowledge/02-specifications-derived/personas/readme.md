# Personas Library

This folder contains the authoritative RBM persona definitions, organised by category.

## Categories

- `Governance-Assurance`
- `Technology-Platform`
- `Change-Leadership`
- `Operational-Authoring`
