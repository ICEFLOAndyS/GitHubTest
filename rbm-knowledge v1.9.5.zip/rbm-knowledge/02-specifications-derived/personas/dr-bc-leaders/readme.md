# Disaster Recovery & Business Continuity Leader Personas

This category covers senior and operational leaders responsible for Business Continuity, Disaster Recovery, service recovery, crisis management, and resilience testing.

## Personas

- **Head of Business Continuity** — `Head-of-Business-Continuity.md`
- **Disaster Recovery Lead** — `Disaster-Recovery-Lead.md`
- **Service Recovery Manager** — `Service-Recovery-Manager.md`
- **Crisis Management Lead** — `Crisis-Management-Lead.md`
- **Resilience Testing Manager** — `Resilience-Testing-Manager.md`