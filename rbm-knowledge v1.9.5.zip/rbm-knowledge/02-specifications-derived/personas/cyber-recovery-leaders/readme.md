# Cyber Recovery Leader Personas

This category covers leaders responsible for cyber recovery planning, execution, architecture, and testing following severe cyber incidents.

## Personas

- **Head of Cyber Recovery** — `Head-of-Cyber-Recovery.md`
- **Cyber Incident Response Lead** — `Cyber-Incident-Response-Lead.md`
- **Cyber Recovery Architecture Lead** — `Cyber-Recovery-Architecture-Lead.md`
- **Ransomware Recovery Manager** — `Ransomware-Recovery-Manager.md`
- **Cyber Recovery Testing Manager** — `Cyber-Recovery-Testing-Manager.md`