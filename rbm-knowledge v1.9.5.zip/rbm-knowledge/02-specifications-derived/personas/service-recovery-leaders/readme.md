# Service Recovery Leader Personas

This category covers leaders and managers responsible for restoring business services following major incidents.

## Personas

- **Head of Service Recovery** — `Head-of-Service-Recovery.md`
- **Major Incident Manager** — `Major-Incident-Manager.md`
- **Service Restoration Manager** — `Service-Restoration-Manager.md`
- **Service Owner** — `Service-Owner.md`
- **Recovery Communications Lead** — `Recovery-Communications-Lead.md`