# Operational-Authoring

## Personas in this category

- **Content Author** — `Content-Author.md`
- **Template Author** — `Template-Author.md`
- **Component Author** — `Component-Author.md`
- **Team Leader** — `Team-Leader.md`
- **Task Agent / Owner** — `Task-Agent-Owner.md`
- **Event Support Analyst** — `Event-Support-Analyst.md`
- **Runbook Engineer** - `Runbook-Engineer.md`
- **Head of Procurement** — `Head-of-Procurement.md`
- **Head of BC/DR** — `Head-of-BC-DR.md`
