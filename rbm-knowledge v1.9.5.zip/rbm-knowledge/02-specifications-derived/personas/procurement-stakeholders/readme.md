# Procurement Stakeholder Personas

This category covers personas involved in procurement decisions, including enablers, qualifiers, and blockers.

## Personas

- **Head of Procurement** — `Head-of-Procurement.md`
- **Commercial Manager** — `Commercial-Manager.md`
- **Vendor Management Office (VMO) Lead** — `Vendor-Management-Office.md`
- **Legal Counsel (Commercial / Technology)** — `Legal-Counsel.md`
- **Enterprise Risk Manager** — `Risk-Management.md`