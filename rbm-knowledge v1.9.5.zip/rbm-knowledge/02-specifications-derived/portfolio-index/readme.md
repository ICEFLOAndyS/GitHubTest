# Portfolio Index

Entry point for humans and AI agents. Contains glossary and taxonomy.