# Definition of Done Framework (v1.0)

Generated: 2025-12-28 14:49:30

Defines how DoDs are structured and enforced.

- Orchestrator DoD: global governance gate
- Feature DoD: acceptance criteria
- Build DoD: technical completion

DoDs are enforced hierarchically and must be evidenced.
