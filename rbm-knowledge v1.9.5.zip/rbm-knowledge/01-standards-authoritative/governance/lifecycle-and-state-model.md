# Lifecycle and State Model (v1.0)

Generated: 2025-12-28 14:49:30

Defines standard lifecycle states for features and artefacts:
- draft
- ready-for-design
- designed
- ready-for-build
- in-build
- ready-for-test
- approved
- released

Transitions must be explicit and governed.
