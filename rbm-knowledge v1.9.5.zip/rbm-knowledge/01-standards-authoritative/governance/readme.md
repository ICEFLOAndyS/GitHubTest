# Governance

Defines portfolio-wide governance, ownership, RACI, and change control.