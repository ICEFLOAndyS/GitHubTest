# id

Stable ID utility for deterministic, accessible component IDs.
