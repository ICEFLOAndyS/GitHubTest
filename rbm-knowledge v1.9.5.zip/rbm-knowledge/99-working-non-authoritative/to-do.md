## Themes

Consider Themes and color pallettes, dark & light themes
Refer to ServiceNow IDE Setup project
Horizon chat

## REFERENCES

#Internal
Review all references to make explicit and accurate references to corrent Knowledge documents 

#External
Review all references to make context specific references to external sources e.g. development standards

## Component Catalogue Files
Add Classification (as per Knowledge Design prompt)

## UI standards
Add path to these standards to the component catalogue Files

