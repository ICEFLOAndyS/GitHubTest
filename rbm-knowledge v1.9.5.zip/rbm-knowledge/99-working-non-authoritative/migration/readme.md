# Migration artefacts

Generated: 2025-12-28 09:20:18

- `rename-map.json` maps original relative paths to new repository paths.
- `manifest.json` includes file sizes and SHA-256 hashes for integrity checking.
- Collisions are resolved by appending an 8-character hash suffix to the filename.

Text-like files updated (internal reference rewrites): 2
Collision count: 0
